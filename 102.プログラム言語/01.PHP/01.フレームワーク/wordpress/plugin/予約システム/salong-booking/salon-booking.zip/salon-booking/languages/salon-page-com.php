<?php 
class Salon_Country {
	static function echoZipTable() {

	}

	static function echoZipFunc($target,$set) {

	}
}