<?php 
$holiday = array(
	array(20140101,"New Year's Day"),
	array(20140120,"Birthday of Martin Luther King Jr."),
	array(20140217,"Washington's Birthday"),
	array(20140526,"Memorial Day"),
	array(20140704,"Independence Day"),
	array(20140901,"Labor Day"),
	array(20141013,"Columbus Day"),
	array(20141111,"Veterans Day"),
	array(20141127,"Thanksgiving Day"),
	array(20141225,"Christmas Day"),
);
